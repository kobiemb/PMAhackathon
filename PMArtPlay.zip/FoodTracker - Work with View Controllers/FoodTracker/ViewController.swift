//
//  ViewController.swift
//  FoodTracker
//
//  Created by Jane Appleseed on 5/23/15.
//  Copyright © 2015 Apple Inc. All rights reserved.
//  See LICENSE.txt for this sample’s licensing information.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    // MARK: Properties
    let locationManager = pmaLocationManager()
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var mealNameLabel: UILabel!
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var selectImageFromLibrary: UIButton!
    @IBOutlet weak var processPhoto: UIButton!
    @IBOutlet weak var stackContainer: UIStackView!
    @IBOutlet weak var executeArtPlay: UIBarButtonItem!
    @IBOutlet weak var saveImage: UIBarButtonItem!
    @IBOutlet weak var shareImage: UIBarButtonItem!
    
    @IBOutlet weak var currentLocationLabel: UILabel!
    @IBOutlet weak var currentHeadingLabel: UILabel!
    
    var parseObject:PFObject?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Handle the text field’s user input through delegate callbacks.
        nameTextField.delegate = self
        //photoImageView.image = UIImage(named: "defaultPhoto.imageset")
        photoImageView.alpha = 0.5
        selectImageFromLibrary.titleLabel?.text = "Or select a moment \u{1F496}"
        
        
        pmaToolkit.settings.iBeaconUUID = "f7826da6-4fa2-4e98-8024-bc5b71e0893e"
        
        pmaToolkit.settings.cacheSettings.hostProtocol = "https://"
        pmaToolkit.settings.cacheSettings.hostName = "raw.githubusercontent.com"
        pmaToolkit.settings.cacheSettings.urlBeacons = "philamuseum/hackathon/master/data/PMAPowerofArtHackathon-ibeacons.json"
        pmaToolkit.settings.cacheSettings.urlLocations = "philamuseum/hackathon/master/data/PMAPowerofArtHackathon-locations.json"
        
        locationManager.startUpdateHeading()
        locationManager.startRangingBeacons(.MainBuilding)
        
        pmaToolkit.registerNotification(self, function: "locationChanged:", type: "locationChanged")
        pmaToolkit.registerNotification(self, function: "locationUnknown:", type: "locationUnknown")
        
        pmaToolkit.registerNotification(self, function: "headingUpdated:", type: "didUpdateHeading")
        
        // This is optional and another way to keep checking if we currently know where we are inside the building
        NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: Selector("checkForCurrentLocation"), userInfo: nil, repeats: true)

        
    }
    
    // MARK :iBeacon Code
    func checkForCurrentLocation() {
        pmaToolkit.logInfo("CURRENT LOCATION: \(self.locationManager.getCurrentLocation()?.name)")
    }
    
    func locationUnknown(notification: NSNotification) {
        if let location = pmaToolkit.getObjectFromNotificationForKey(notification, key: "lastKnownLocation") as? pmaLocation {
            currentLocationLabel.text = "CURRENT LOCATION: N/A [Last: \(location.name)]"
        } else {
            currentLocationLabel.text = "CURRENT LOCATION: N/A"
        }
    }
    
    func locationChanged(notification: NSNotification) {
        if let location = pmaToolkit.getObjectFromNotificationForKey(notification, key: "currentLocation") as? pmaLocation {
            currentLocationLabel.text = "CURRENT LOCATION: \(location.name)"
        }
    }
    
    func headingUpdated(notification: NSNotification) {
        if let heading = pmaToolkit.getObjectFromNotificationForKey(notification, key: "calculatedHeadingRadians") as? CGFloat {
            currentHeadingLabel.text = "CURRENT HEADING: \(heading)"
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: UITextFieldDelegate
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        mealNameLabel.text = textField.text
    }

    
    // MARK: UIImagePickerControllerDelegate
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        // Dismiss the picker if the user canceled.
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        // The info dictionary contains multiple representations of the image, and this uses the original.
        let selectedImage = info[UIImagePickerControllerEditedImage] as! UIImage
        
        // Set photoImageView to display the selected image.
        photoImageView.image = selectedImage
        photoImageView.layer.sublayers = nil
        photoImageView.alpha = 1;
        // Dismiss the picker.
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    func flattenImage()->UIImage{
        UIGraphicsBeginImageContext(photoImageView.frame.size)
        photoImageView.layer.renderInContext(UIGraphicsGetCurrentContext()!)
        let imageData = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext();
        return imageData
    }
    
    func image(image: UIImage, didFinishSavingWithError error: NSError?, contextInfo:UnsafePointer<Void>) {
        if error == nil {
            let ac = UIAlertController(title: "Saved!", message: "Your altered image has been saved to your photos.", preferredStyle: .Alert)
            ac.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
            presentViewController(ac, animated: true, completion: nil)
        } else {
            let ac = UIAlertController(title: "Save error", message: error?.localizedDescription, preferredStyle: .Alert)
            ac.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
            presentViewController(ac, animated: true, completion: nil)
        }
    }
    
    // MARK: Server Handling
    func uploadImage(imageDataRaw: UIImage){
        let locationFilename = String("234.png")
        
        if let imageData = UIImagePNGRepresentation(imageDataRaw),
            let imageFile = PFFile(name: locationFilename, data: imageData),
            let currentUser = PFUser.currentUser() {
                currentUser.setObject(imageFile, forKey: "selfieImage")
                currentUser.saveInBackgroundWithBlock({
                    (success: Bool, error: NSError?) -> Void in
                
                    if error == nil {
                        let alertController = UIAlertController(title: "iOScreator", message:
                            "Success", preferredStyle: UIAlertControllerStyle.Alert)
                        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
                    
                        self.presentViewController(alertController, animated: true, completion: nil)
                    }
                    else {
                        let alertController = UIAlertController(title: "iOScreator", message:
                            "Unknown Error", preferredStyle: UIAlertControllerStyle.Alert)
                        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
                    
                        self.presentViewController(alertController, animated: true, completion: nil)
                    }
                })
            }
        else {
            let alertController = UIAlertController(title: "iOScreator", message:
                "Unknown Error", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
        }
    }
    
    func shareTextImageAndURL(sharingText: String?, sharingImage: UIImage?, sharingURL: NSURL?) {
        var sharingItems = [AnyObject]()
        
        if let text = sharingText {
            sharingItems.append(text)
        }
        if let image = sharingImage {
            sharingItems.append(image)
        }
        if let url = sharingURL {
            sharingItems.append(url)
        }
        
        let activityViewController = UIActivityViewController(activityItems: sharingItems, applicationActivities: nil)
        self.presentViewController(activityViewController, animated: true, completion: nil)
    }
    
    // MARK: Actions
    @IBAction func captureImageFromCamera(sender: UITapGestureRecognizer) {
        // Hide the keyboard.
        nameTextField.resignFirstResponder()
        
        // UIImagePickerController is a view controller that lets a user pick media from their photo library.
        let imagePickerController = UIImagePickerController()
        
        // Only allow photos to be picked, not taken.
        imagePickerController.sourceType = .Camera
        
        // Make sure ViewController is notified when the user picks an image.
        imagePickerController.delegate = self
        imagePickerController.allowsEditing = true
        
        presentViewController(imagePickerController, animated: true, completion: nil)
    }
    
    @IBAction func selectImageFromPhotoLibrary(sender: UITapGestureRecognizer) {
        // Hide the keyboard.
        nameTextField.resignFirstResponder()
        
        // UIImagePickerController is a view controller that lets a user pick media from their photo library.
        let imagePickerController = UIImagePickerController()
        
        // Only allow photos to be picked, not taken.
        imagePickerController.sourceType = .PhotoLibrary
        
        // Make sure ViewController is notified when the user picks an image.
        imagePickerController.delegate = self
        imagePickerController.allowsEditing = true
        
        presentViewController(imagePickerController, animated: true, completion: nil)
    }
    
    @IBAction func applyTextToImage(sender: UIButton) {
        //mealNameLabel.text = "Default Text"
        photoImageView.layer.sublayers = nil
        let textLayer = CATextLayer()
        textLayer.frame = photoImageView.bounds
        let photoCaption = mealNameLabel.text
        textLayer.string = photoCaption
        
        let fontName: CFStringRef = "Avenir-Book"
        textLayer.font = CTFontCreateWithName(fontName, 16, nil)
        
        textLayer.foregroundColor = UIColor.darkGrayColor().CGColor
        textLayer.wrapped = true
        textLayer.alignmentMode = kCAAlignmentCenter
        //textLayer.frame.origin.y = photoImageView.bounds.origin.y - textLayer.frame.size.height
        textLayer.frame.origin.y = photoImageView.bounds.origin.y + photoImageView.frame.height - (textLayer.bounds.height)
        
        textLayer.contentsScale = UIScreen.mainScreen().scale
        photoImageView.layer.addSublayer(textLayer)
        
    }
    
    @IBAction func sendImageToServer(sender: UIBarButtonItem) {
        let imageData = flattenImage()

        //Display Busy Icon
        
        //Execute Send
        let sendSuccess = uploadImage(imageData)
        
        //Clear Busy Icon
        
        //Send Success Display message
        
        //Send Fail Display message
    }
    
    @IBAction func saveImageToLibrary(sender: UIBarButtonItem) {
        let imageData = flattenImage()
        UIImageWriteToSavedPhotosAlbum(imageData, self, "image:didFinishSavingWithError:contextInfo:", nil)
    }
    
    @IBAction func shareImageClicked(sender: UIBarButtonItem) {
        let imageData = flattenImage()
        let shareURL = NSURL()
        shareTextImageAndURL(mealNameLabel.text,sharingImage: imageData, sharingURL: shareURL)
    }
    
    
    
}

