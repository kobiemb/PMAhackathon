//
//  pmaToolkit.h
//  pmaToolkit
//
//  Created by Peter.Alt on 2/24/16.
//  Copyright © 2016 Philadelphia Museum of Art. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for pmaToolkit.
FOUNDATION_EXPORT double pmaToolkitVersionNumber;

//! Project version string for pmaToolkit.
FOUNDATION_EXPORT const unsigned char pmaToolkitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <pmaToolkit/PublicHeader.h>


