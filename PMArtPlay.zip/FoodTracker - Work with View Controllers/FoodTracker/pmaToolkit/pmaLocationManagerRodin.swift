//
//  pmaLocationManagerRodin.swift
//  pmaToolkit
//
//  Created by Peter.Alt on 2/25/16.
//  Copyright © 2016 Philadelphia Museum of Art. All rights reserved.
//

extension pmaLocationManager {
    
}
