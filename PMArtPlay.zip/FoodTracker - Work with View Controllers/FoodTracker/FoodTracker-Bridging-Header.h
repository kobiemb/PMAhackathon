//
//  FoodTracker-Bridging-Header.h
//  FoodTracker
//
//  Created by TKO_MBAir on 3/13/16.
//  Copyright © 2016 Apple Inc. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <Parse/Parse.h>
#import <pmaToolkit/pmaToolkit.h>
#import <SwiftyJSON/SwiftyJSON.h>